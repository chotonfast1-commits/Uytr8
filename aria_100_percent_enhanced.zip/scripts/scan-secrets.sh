#!/usr/bin/env bash
# Fails if anything that looks like a Google/Gemini API key or an assigned key value is found. Usage: scan-secrets.sh <dir>
set -u; DIR="${1:-.}"; bad=0
if grep -rEIn --exclude-dir={node_modules,.git,build,.gradle} 'AIza[0-9A-Za-z_-]{30,}' "$DIR"; then bad=1; fi
if grep -rEIn --exclude-dir={node_modules,.git,build,.gradle} --exclude=scan-secrets.sh "(API_KEY|api_key|apiKey|SIGNING_SECRET|REGISTRATION_KEY)[\"']?[[:space:]]*[=:][[:space:]]*[\"']?[A-Za-z0-9_+/=-]{16,}" "$DIR" | grep -v 'test-key-not-real\|process.env\|env\[\|set-secrets' ; then bad=1; fi
[ $bad -eq 0 ] && echo "secret scan: clean" || echo "secret scan: FOUND POSSIBLE SECRETS"; exit $bad
