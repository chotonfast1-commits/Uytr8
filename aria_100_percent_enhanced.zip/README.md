# Aria – Android voice assistant + Gemini proxy

```
Android app ──(Bearer session token)──▶ proxy (Cloud Run) ──(x-goog-api-key, server-side only)──▶ Gemini
```

## 1. Deploy the proxy (`proxy/`)
```
cd proxy && npm test
PROJECT_ID=my-project REGION=us-central1 ./deploy/deploy.sh
```
The script stores three values in Secret Manager and binds them as env vars: `GEMINI_API_KEY`, `TOKEN_SIGNING_SECRET`,
`REGISTRATION_KEY`. It prints the service URL. The Gemini key is typed into a hidden prompt; it never touches a file,
the repo, the APK or logs. Model defaults to `gemini-2.5-flash` (`GEMINI_MODEL` env var) – confirm it is current for your account.

## 2. Build the Android app
Provide (env vars or `~/.gradle/gradle.properties`, never committed):
`ARIA_PROXY_BASE_URL=https://<service-url>` and `ARIA_REGISTRATION_KEY=<value of aria-registration-key>`.
Open in Android Studio and Run, or `gradle :app:assembleDebug`. CI: `.github/workflows/android.yml`.

## API contract
- `POST /v1/register` header `X-Aria-Registration` → `{token, expires_at}` (30-day signed token)
- `POST /v1/assistant` header `Authorization: Bearer <token>`, body `{user_name, ai_name, language(en|hi|bn), message, memories[≤50], history[≤6 {role,text}]}`
  → `{reply, action?:{type,target}, consequential, confirm_prompt?}`
- Errors: `{"error":{"code","message","retry_after_seconds?"},"request_id"}`; codes: `invalid_token, unauthorized, rate_limited,
  invalid_request, invalid_json, payload_too_large, unsupported_media_type, upstream_timeout, upstream_busy, upstream_unreachable,
  upstream_error, bad_upstream_response, blocked, internal_error`.

## Security notes (read these)
- The registration key ships inside the APK (build-time) and can be extracted by a determined person. It is NOT the Gemini key,
  but it means anyone can obtain session tokens. Mitigations in place: per-install and per-IP rate limits, registration rate limit,
  request size/shape validation, Cloud Run `--max-instances`. For real app-only access add Play Integrity attestation to `/v1/register`.
- Rate limits are in-memory per instance (up to `--max-instances` × limit). Use Redis/Firestore if you scale out.
- Accessibility must be enabled by the user in Android Settings. Wake-word listening is not implemented.
