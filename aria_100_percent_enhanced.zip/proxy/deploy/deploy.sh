#!/usr/bin/env bash
# Deploys the proxy to Cloud Run with secrets from Secret Manager. Run from the proxy/ directory.
# Prereqs: gcloud CLI logged in, billing enabled, PROJECT_ID and REGION set.
set -euo pipefail
: "${PROJECT_ID:?set PROJECT_ID}"; : "${REGION:=us-central1}"; SERVICE=aria-proxy
gcloud config set project "$PROJECT_ID"
gcloud services enable run.googleapis.com secretmanager.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com

mk_secret() { # name, prompt, generate-if-empty
  if gcloud secrets describe "$1" >/dev/null 2>&1; then echo "secret $1 exists (add a new version manually to rotate)"; return; fi
  local v; read -rsp "$2 (leave empty to auto-generate): " v; echo
  if [ -z "$v" ] && [ "${3:-}" = gen ]; then v="$(openssl rand -base64 48 | tr -d '\n')"; fi
  [ -n "$v" ] || { echo "value required"; exit 1; }
  printf %s "$v" | gcloud secrets create "$1" --replication-policy=automatic --data-file=-   # value never echoed or logged
}
mk_secret aria-gemini-api-key "Gemini API key"
mk_secret aria-token-signing-secret "Token signing secret" gen
mk_secret aria-registration-key "App registration key (must match ARIA_REGISTRATION_KEY in the Android build)" gen

PROJECT_NUMBER="$(gcloud projects describe "$PROJECT_ID" --format='value(projectNumber)')"
for s in aria-gemini-api-key aria-token-signing-secret aria-registration-key; do
  gcloud secrets add-iam-policy-binding "$s" --member="serviceAccount:${PROJECT_NUMBER}-compute@developer.gserviceaccount.com" --role=roles/secretmanager.secretAccessor >/dev/null
done

gcloud run deploy "$SERVICE" --source . --region "$REGION" --allow-unauthenticated \
  --max-instances=2 --concurrency=40 --timeout=30 --memory=256Mi \
  --set-env-vars="TRUST_PROXY=1,GEMINI_MODEL=${GEMINI_MODEL:-gemini-2.5-flash}" \
  --set-secrets="GEMINI_API_KEY=aria-gemini-api-key:latest,TOKEN_SIGNING_SECRET=aria-token-signing-secret:latest,REGISTRATION_KEY=aria-registration-key:latest"
echo "Service URL (use as ARIA_PROXY_BASE_URL):"; gcloud run services describe "$SERVICE" --region "$REGION" --format='value(status.url)'
echo "Registration key for the Android build: gcloud secrets versions access latest --secret=aria-registration-key"
