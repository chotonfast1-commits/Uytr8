// TEST FIXTURE ONLY: a local HTTP server stands in for Generative Language API so the proxy's own logic
// (auth, limits, validation, error mapping, request shape) can be exercised offline. It is not shipped or used at runtime.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createServer } from '../src/server.js';
import { loadConfig } from '../src/config.js';

const FAKE_KEY = 'test-key-not-real-0123456789';
let upstreamMode = 'ok'; let lastUpstream = null;
const upstream = http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => (b += c));
  req.on('end', () => {
    lastUpstream = { url: req.url, headers: req.headers, body: JSON.parse(b) };
    if (upstreamMode === 'hang') return; // never answers
    if (upstreamMode === '500') { res.writeHead(500); return res.end('{"error":"secret upstream detail"}'); }
    if (upstreamMode === '429') { res.writeHead(429); return res.end('{}'); }
    if (upstreamMode === 'garbage') { res.writeHead(200); return res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'not json' }] } }] })); }
    if (upstreamMode === 'blocked') { res.writeHead(200); return res.end(JSON.stringify({ promptFeedback: { blockReason: 'SAFETY' } })); }
    const out = { reply: 'Sure Sir.', action: { type: 'open_app', target: 'YouTube' }, consequential: false, confirm_prompt: null };
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(out) }] }, finishReason: 'STOP' }] }));
  });
});

const logs = [];
let proxy, base, upBase;
const env = (extra = {}) => ({ GEMINI_API_KEY: FAKE_KEY, TOKEN_SIGNING_SECRET: 's'.repeat(40), REGISTRATION_KEY: 'reg-key-1', GEMINI_BASE_URL: upBase, GEMINI_TIMEOUT_MS: '300', ...extra });

async function start(extra) {
  proxy = createServer(loadConfig(env(extra)), { log: (o) => logs.push(JSON.stringify(o)) });
  await new Promise((r) => proxy.listen(0, r)); base = `http://127.0.0.1:${proxy.address().port}`;
}
const stop = () => new Promise((r) => proxy.close(r));
const call = (path, { method = 'POST', headers = {}, body } = {}) =>
  fetch(base + path, { method, headers: { 'content-type': 'application/json', ...headers }, body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body) });
const token = async () => (await (await call('/v1/register', { headers: { 'x-aria-registration': 'reg-key-1' }, body: {} })).json()).token;
const good = { user_name: 'Sir', ai_name: 'Aria', language: 'en', message: 'YouTube kholo', memories: ['likes cricket'], history: [{ role: 'user', text: 'hi' }] };

test.before(async () => { await new Promise((r) => upstream.listen(0, r)); upBase = `http://127.0.0.1:${upstream.address().port}`; });
test.after(() => upstream.close());
test.beforeEach(async () => { upstreamMode = 'ok'; await start(); });
test.afterEach(stop);

test('config fails fast without secrets', () => {
  assert.throws(() => loadConfig({}), /GEMINI_API_KEY/);
  assert.throws(() => loadConfig({ GEMINI_API_KEY: 'x', TOKEN_SIGNING_SECRET: 'short', REGISTRATION_KEY: 'y' }), /32/);
});
test('healthz', async () => assert.equal((await call('/healthz', { method: 'GET' })).status, 200));
test('register rejects wrong key, accepts right key', async () => {
  const bad = await call('/v1/register', { headers: { 'x-aria-registration': 'nope' }, body: {} });
  assert.equal(bad.status, 401); assert.equal((await bad.json()).error.code, 'unauthorized');
  assert.ok(await token());
});
test('assistant needs a valid token', async () => {
  assert.equal((await call('/v1/assistant', { body: good })).status, 401);
  const r = await call('/v1/assistant', { headers: { authorization: 'Bearer v1.abc.def' }, body: good });
  assert.equal(r.status, 401); assert.equal((await r.json()).error.code, 'invalid_token');
});
test('tampered token rejected', async () => {
  const t = await token(); const [v, p, s] = t.split('.');
  const forged = `${v}.${Buffer.from(JSON.stringify({ iid: 'x', exp: Date.now() + 1e9 })).toString('base64url')}.${s}`;
  assert.equal((await call('/v1/assistant', { headers: { authorization: `Bearer ${forged}` }, body: good })).status, 401);
});
test('valid request returns contract JSON; key only in header, never URL/body/response', async () => {
  const r = await call('/v1/assistant', { headers: { authorization: `Bearer ${await token()}` }, body: good });
  assert.equal(r.status, 200); const j = await r.json();
  assert.deepEqual(j, { reply: 'Sure Sir.', consequential: false, action: { type: 'open_app', target: 'YouTube' } });
  assert.equal(lastUpstream.headers['x-goog-api-key'], FAKE_KEY);
  assert.ok(!lastUpstream.url.includes(FAKE_KEY)); assert.ok(!JSON.stringify(lastUpstream.body).includes(FAKE_KEY));
  assert.ok(!JSON.stringify(j).includes(FAKE_KEY));
  assert.match(lastUpstream.body.systemInstruction.parts[0].text, /likes cricket/);
  assert.equal(lastUpstream.body.contents.at(-1).parts[0].text, 'YouTube kholo');
});
test('validation errors are structured 400s', async () => {
  const h = { authorization: `Bearer ${await token()}` };
  for (const body of [{ ...good, language: 'fr' }, { ...good, message: '' }, { ...good, message: 'x'.repeat(1001) }, { ...good, history: new Array(7).fill({ role: 'user', text: 'a' }) },
    { ...good, history: [{ role: 'system', text: 'a' }] }, { ...good, memories: 'x' }, []]) {
    const r = await call('/v1/assistant', { headers: h, body }); assert.equal(r.status, 400); assert.equal((await r.json()).error.code, 'invalid_request');
  }
  const bad = await call('/v1/assistant', { headers: h, body: '{nope' }); assert.equal((await bad.json()).error.code, 'invalid_json');
  const big = await call('/v1/assistant', { headers: h, body: { ...good, pad: 'x'.repeat(20000) } }); assert.equal(big.status, 413);
  const ct = await fetch(base + '/v1/assistant', { method: 'POST', headers: { ...h, 'content-type': 'text/plain' }, body: 'x' }); assert.equal(ct.status, 415);
});
test('upstream failures map to clean errors without leaking detail', async () => {
  const h = { authorization: `Bearer ${await token()}` };
  const expect = { '500': [502, 'upstream_error'], '429': [503, 'upstream_busy'], garbage: [502, 'bad_upstream_response'], blocked: [422, 'blocked'], hang: [504, 'upstream_timeout'] };
  for (const [mode, [status, code]] of Object.entries(expect)) {
    upstreamMode = mode; const r = await call('/v1/assistant', { headers: h, body: good }); const j = await r.json();
    assert.equal(r.status, status, mode); assert.equal(j.error.code, code, mode); assert.ok(!JSON.stringify(j).includes('secret upstream detail'));
  }
});
test('upstream unreachable', async () => {
  await stop(); await start({ GEMINI_BASE_URL: 'http://127.0.0.1:1' });
  const r = await call('/v1/assistant', { headers: { authorization: `Bearer ${await token()}` }, body: good });
  assert.equal(r.status, 502); assert.equal((await r.json()).error.code, 'upstream_unreachable');
});
test('per-install rate limit returns 429 with retry info', async () => {
  await stop(); await start({ LIMIT_ASSISTANT_PER_MIN: '2' });
  const h = { authorization: `Bearer ${await token()}` };
  assert.equal((await call('/v1/assistant', { headers: h, body: good })).status, 200);
  assert.equal((await call('/v1/assistant', { headers: h, body: good })).status, 200);
  const r = await call('/v1/assistant', { headers: h, body: good }); const j = await r.json();
  assert.equal(r.status, 429); assert.equal(j.error.code, 'rate_limited'); assert.ok(j.error.retry_after_seconds >= 1); assert.ok(r.headers.get('retry-after'));
});
test('registration is rate limited per IP', async () => {
  await stop(); await start({ LIMIT_REGISTER_PER_IP_HOUR: '2' });
  for (let i = 0; i < 2; i++) await call('/v1/register', { headers: { 'x-aria-registration': 'reg-key-1' }, body: {} });
  assert.equal((await call('/v1/register', { headers: { 'x-aria-registration': 'reg-key-1' }, body: {} })).status, 429);
});
test('unknown route / wrong method', async () => {
  assert.equal((await call('/nope', { method: 'GET' })).status, 404);
  assert.equal((await call('/v1/assistant', { method: 'GET' })).status, 405);
});
test('logs never contain key, tokens or message text', async () => {
  await call('/v1/assistant', { headers: { authorization: `Bearer ${await token()}` }, body: good });
  const all = logs.join('\n');
  assert.ok(all.length > 0); assert.ok(!all.includes(FAKE_KEY)); assert.ok(!all.includes('YouTube kholo')); assert.ok(!all.includes('v1.'));
});
