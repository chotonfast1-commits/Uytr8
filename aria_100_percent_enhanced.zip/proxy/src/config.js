// All secrets come from the environment (Cloud Run Secret Manager bindings). Nothing is read from files or defaults.
export function loadConfig(env = process.env) {
  const req = (k) => { if (!env[k]) throw new Error(`Missing required env var ${k}`); return env[k]; };
  const cfg = {
    port: Number(env.PORT || 8080),
    geminiKey: req('GEMINI_API_KEY'),
    signingSecret: req('TOKEN_SIGNING_SECRET'),
    registrationKey: req('REGISTRATION_KEY'),
    model: env.GEMINI_MODEL || 'gemini-2.5-flash',
    geminiBase: env.GEMINI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta',
    timeoutMs: Number(env.GEMINI_TIMEOUT_MS || 20000),
    tokenTtlDays: Number(env.TOKEN_TTL_DAYS || 30),
    trustProxy: env.TRUST_PROXY === '1',
    limits: {
      assistantPerMin: Number(env.LIMIT_ASSISTANT_PER_MIN || 20),
      assistantPerDay: Number(env.LIMIT_ASSISTANT_PER_DAY || 600),
      ipPerMin: Number(env.LIMIT_IP_PER_MIN || 60),
      registerPerIpPerHour: Number(env.LIMIT_REGISTER_PER_IP_HOUR || 10)
    }
  };
  if (cfg.signingSecret.length < 32) throw new Error('TOKEN_SIGNING_SECRET must be at least 32 characters');
  return cfg;
}
