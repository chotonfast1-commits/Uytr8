// Fixed-window counters, in memory. Per-instance: with several Cloud Run instances each keeps its own counts.
export class RateLimiter {
  constructor() { this.m = new Map(); this.t = setInterval(() => this.sweep(), 60_000); this.t.unref(); }
  hit(key, limit, windowMs, now = Date.now()) {
    let e = this.m.get(key);
    if (!e || e.reset <= now) { e = { count: 0, reset: now + windowMs }; this.m.set(key, e); }
    e.count++;
    return { ok: e.count <= limit, retryAfter: Math.max(1, Math.ceil((e.reset - now) / 1000)) };
  }
  sweep(now = Date.now()) { for (const [k, e] of this.m) if (e.reset <= now) this.m.delete(k); }
  close() { clearInterval(this.t); }
}
