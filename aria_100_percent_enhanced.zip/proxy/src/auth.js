import crypto from 'node:crypto';

const sign = (secret, payload) => crypto.createHmac('sha256', secret).update('v1.' + payload).digest('base64url');

export function issueToken(secret, ttlDays, now = Date.now()) {
  const iid = crypto.randomUUID();
  const exp = now + ttlDays * 86_400_000;
  const payload = Buffer.from(JSON.stringify({ iid, exp })).toString('base64url');
  return { token: `v1.${payload}.${sign(secret, payload)}`, expiresAt: exp, installId: iid };
}

export function verifyToken(secret, token, now = Date.now()) {
  if (typeof token !== 'string' || token.length > 512) return null;
  const parts = token.split('.');
  if (parts.length !== 3 || parts[0] !== 'v1') return null;
  const given = Buffer.from(parts[2]); const want = Buffer.from(sign(secret, parts[1]));
  if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) return null;
  try {
    const d = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
    return typeof d.exp === 'number' && d.exp > now && typeof d.iid === 'string' ? d : null;
  } catch { return null; }
}

export function safeEqual(a, b) {
  const h = (x) => crypto.createHash('sha256').update(String(x)).digest();
  return crypto.timingSafeEqual(h(a), h(b));
}
