import http from 'node:http';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { loadConfig } from './config.js';
import { issueToken, verifyToken, safeEqual } from './auth.js';
import { RateLimiter } from './ratelimit.js';
import { validateAssistantBody } from './validate.js';
import { callGemini, UpstreamError } from './gemini.js';

const MAX_BODY = 16 * 1024;

export function createServer(cfg, { log = defaultLog, fetchImpl = fetch } = {}) {
  const limiter = new RateLimiter();

  const send = (res, status, obj, extra = {}) => {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'content-length': Buffer.byteLength(body), ...(status === 413 ? { connection: 'close' } : {}), ...extra });
    res.end(body);
  };
  const fail = (res, rid, status, code, message, retryAfter) =>
    send(res, status, { error: { code, message, ...(retryAfter ? { retry_after_seconds: retryAfter } : {}) }, request_id: rid },
      retryAfter ? { 'retry-after': String(retryAfter) } : {});

  const clientIp = (req) => {
    if (cfg.trustProxy) { const x = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean); if (x.length) return x[x.length - 1]; }
    return req.socket.remoteAddress || 'unknown';
  };

  const readJson = (req) => new Promise((resolve, reject) => {
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) return reject({ status: 415, code: 'unsupported_media_type', message: 'Content-Type must be application/json.' });
    let size = 0; const chunks = [];
    let tooBig = false;
    req.on('data', (c) => { if (tooBig) return; size += c.length; if (size > MAX_BODY) { tooBig = true; chunks.length = 0; reject({ status: 413, code: 'payload_too_large', message: 'Request body too large.' }); } else chunks.push(c); }); // drain, don't reset the socket
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject({ status: 400, code: 'invalid_json', message: 'Body is not valid JSON.' }); } });
    req.on('error', () => reject({ status: 400, code: 'invalid_request', message: 'Could not read request.' }));
  });

  const server = http.createServer(async (req, res) => {
    const rid = crypto.randomUUID(); const t0 = Date.now(); const path = (req.url || '').split('?')[0];
    res.on('finish', () => log({ rid, method: req.method, path, status: res.statusCode, ms: Date.now() - t0 })); // no bodies, no headers
    try {
      if (path === '/healthz') return send(res, 200, { ok: true });
      const ip = clientIp(req);

      if (path === '/v1/register') {
        if (req.method !== 'POST') return fail(res, rid, 405, 'method_not_allowed', 'Use POST.');
        const rl = limiter.hit(`reg:${ip}`, cfg.limits.registerPerIpPerHour, 3_600_000);
        if (!rl.ok) return fail(res, rid, 429, 'rate_limited', 'Too many registrations.', rl.retryAfter);
        if (!safeEqual(req.headers['x-aria-registration'] || '', cfg.registrationKey)) return fail(res, rid, 401, 'unauthorized', 'Invalid registration key.');
        const t = issueToken(cfg.signingSecret, cfg.tokenTtlDays);
        return send(res, 200, { token: t.token, expires_at: t.expiresAt });
      }

      if (path === '/v1/assistant') {
        if (req.method !== 'POST') return fail(res, rid, 405, 'method_not_allowed', 'Use POST.');
        const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
        const claims = m && verifyToken(cfg.signingSecret, m[1]);
        if (!claims) return fail(res, rid, 401, 'invalid_token', 'Missing, invalid or expired token. Register again.');
        for (const [key, limit, win] of [[`ip:${ip}`, cfg.limits.ipPerMin, 60_000], [`min:${claims.iid}`, cfg.limits.assistantPerMin, 60_000], [`day:${claims.iid}`, cfg.limits.assistantPerDay, 86_400_000]]) {
          const rl = limiter.hit(key, limit, win);
          if (!rl.ok) return fail(res, rid, 429, 'rate_limited', 'Too many requests. Slow down.', rl.retryAfter);
        }
        let body;
        try { body = await readJson(req); } catch (e) { return fail(res, rid, e.status || 400, e.code || 'invalid_request', e.message || 'Bad request.'); }
        const v = validateAssistantBody(body);
        if (!v.ok) return fail(res, rid, 400, 'invalid_request', v.message);
        try { return send(res, 200, await callGemini(cfg, v.value, fetchImpl)); }
        catch (e) {
          if (e instanceof UpstreamError) return fail(res, rid, e.status, e.code, e.message);
          log({ rid, level: 'error', msg: 'unexpected', err: e?.name }); return fail(res, rid, 500, 'internal_error', 'Unexpected server error.');
        }
      }
      return fail(res, rid, 404, 'not_found', 'Unknown endpoint.');
    } catch (e) {
      log({ rid, level: 'error', msg: 'unhandled', err: e?.name });
      if (!res.headersSent) fail(res, rid, 500, 'internal_error', 'Unexpected server error.');
    }
  });
  server.headersTimeout = 10_000; server.requestTimeout = 40_000;
  server.on('close', () => limiter.close());
  return server;
}

function defaultLog(o) { console.log(JSON.stringify({ ts: new Date().toISOString(), ...o })); }

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
  const cfg = loadConfig();
  createServer(cfg).listen(cfg.port, () => defaultLog({ msg: 'listening', port: cfg.port, model: cfg.model }));
  for (const s of ['SIGTERM', 'SIGINT']) process.on(s, () => process.exit(0));
}
