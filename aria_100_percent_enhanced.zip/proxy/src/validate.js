const LANGS = new Set(['en', 'hi', 'bn']);
const CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;

function str(v, name, max, { min = 0 } = {}) {
  if (typeof v !== 'string') throw new Error(`${name} must be a string`);
  const t = v.trim();
  if (t.length < min) throw new Error(`${name} must not be empty`);
  if (t.length > max) throw new Error(`${name} is too long (max ${max})`);
  if (CTRL.test(t)) throw new Error(`${name} contains invalid characters`);
  return t;
}

export function validateAssistantBody(b) {
  try {
    if (!b || typeof b !== 'object' || Array.isArray(b)) throw new Error('body must be a JSON object');
    const language = str(b.language, 'language', 5);
    if (!LANGS.has(language)) throw new Error('language must be one of en, hi, bn');
    const memories = b.memories ?? [];
    const history = b.history ?? [];
    if (!Array.isArray(memories) || memories.length > 50) throw new Error('memories must be an array of at most 50 items');
    if (!Array.isArray(history) || history.length > 6) throw new Error('history must be an array of at most 6 items');
    return { ok: true, value: {
      userName: str(b.user_name, 'user_name', 40, { min: 1 }),
      aiName: str(b.ai_name, 'ai_name', 40, { min: 1 }),
      language,
      message: str(b.message, 'message', 1000, { min: 1 }),
      memories: memories.map((m, i) => str(m, `memories[${i}]`, 300)),
      history: history.map((h, i) => {
        if (!h || (h.role !== 'user' && h.role !== 'assistant')) throw new Error(`history[${i}].role must be user or assistant`);
        return { role: h.role, text: str(h.text, `history[${i}].text`, 1000) };
      })
    } };
  } catch (e) { return { ok: false, message: e.message }; }
}
