package com.aria.assistant

import android.accessibilityservice.AccessibilityService
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.aria.assistant.accessibility.AriaAccessibilityService
import kotlinx.coroutines.delay

interface AutomationManager { suspend fun execute(action: AutomationAction): ActionResult }

class AndroidAutomationManager(private val app: Context, private val reader: ScreenReader) : AutomationManager {
    private val pm get() = app.packageManager
    private val svc get() = AriaAccessibilityService.instance
    private val launchCtx: Context get() = svc ?: app

    override suspend fun execute(action: AutomationAction): ActionResult = try {
        when (action) {
            is AutomationAction.OpenApp -> openApp(action.name)
            is AutomationAction.OpenUrl -> openUrl(action.url)
            is AutomationAction.InstallApp -> installApp(action.name)
            AutomationAction.Home -> global(AccessibilityService.GLOBAL_ACTION_HOME)
            AutomationAction.Back -> global(AccessibilityService.GLOBAL_ACTION_BACK)
            AutomationAction.Recents -> global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            is AutomationAction.Tap -> needSvc { if (it.clickByLabel(action.label)) ActionResult.Success() else ActionResult.Failure(FailureReason.ELEMENT_NOT_FOUND, action.label) }
            is AutomationAction.Scroll -> needSvc { if (it.scroll(action.forward)) ActionResult.Success() else ActionResult.Failure(FailureReason.ELEMENT_NOT_FOUND, "scrollable") }
            is AutomationAction.TypeText -> type(action.text)
            is AutomationAction.SearchInApp -> search(action.query)
            AutomationAction.ReadScreen -> needSvc {
                val t = it.readVisible()
                if (t == null) ActionResult.Failure(FailureReason.NOT_ALLOWED, "screen not readable") else ActionResult.Success(t.ifBlank { null })
            }
            is AutomationAction.UninstallApp -> uninstall(action.name)
        }
    } catch (e: SecurityException) { ActionResult.Failure(FailureReason.NOT_ALLOWED, e.message)
    } catch (e: ActivityNotFoundException) { ActionResult.Failure(FailureReason.NOT_ALLOWED, e.message) }

    private inline fun needSvc(block: (AriaAccessibilityService) -> ActionResult): ActionResult =
        svc?.let(block) ?: ActionResult.Failure(FailureReason.ACCESSIBILITY_DISABLED)

    private fun global(id: Int) = needSvc { if (it.performGlobalAction(id)) ActionResult.Success() else ActionResult.Failure(FailureReason.NOT_ALLOWED) }

    private data class Launchable(val label: String, val pkg: String)
    private fun findApp(name: String): Launchable? {
        val q = name.trim().lowercase(); if (q.isEmpty()) return null
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(i, 0).map { Launchable(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        return apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.firstOrNull { it.label.length >= 3 && (it.label.lowercase().contains(q) || q.contains(it.label.lowercase())) }
    }

    private fun openApp(name: String): ActionResult {
        if (name.isBlank()) return ActionResult.Failure(FailureReason.INVALID_ARGUMENT)
        val a = findApp(name) ?: return ActionResult.Failure(FailureReason.APP_NOT_INSTALLED, name)
        val intent = pm.getLaunchIntentForPackage(a.pkg) ?: return ActionResult.Failure(FailureReason.APP_NOT_INSTALLED, name)
        launchCtx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult.Success()
    }

    private fun openUrl(url: String): ActionResult {
        val u = Uri.parse(url.trim())
        if (u.scheme != "https" && u.scheme != "http") return ActionResult.Failure(FailureReason.INVALID_ARGUMENT, url)
        launchCtx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult.Success()
    }

    private fun type(text: String): ActionResult = needSvc {
        when (it.setFocusedText(text)) {
            true -> ActionResult.Success()
            false -> ActionResult.Failure(FailureReason.NOT_ALLOWED, "protected field")
            null -> ActionResult.Failure(FailureReason.ELEMENT_NOT_FOUND, "text field")
        }
    }

    private suspend fun search(query: String): ActionResult {
        val s = svc ?: return ActionResult.Failure(FailureReason.ACCESSIBILITY_DISABLED)
        if (query.isBlank()) return ActionResult.Failure(FailureReason.INVALID_ARGUMENT)
        // Only works if the app exposes an accessible search control.
        if (s.setFocusedText(query) == null) {
            if (!s.clickByLabel("Search")) return ActionResult.Failure(FailureReason.ELEMENT_NOT_FOUND, "search")
            delay(700)
        }
        return when (s.setFocusedText(query)) {
            true -> { delay(200); s.pressImeEnter(); ActionResult.Success() }
            false -> ActionResult.Failure(FailureReason.NOT_ALLOWED, "protected field")
            null -> ActionResult.Failure(FailureReason.ELEMENT_NOT_FOUND, "search field")
        }
    }

    private fun installApp(name: String): ActionResult {
        val q = name.trim()
        if (q.isBlank()) return ActionResult.Failure(FailureReason.INVALID_ARGUMENT)
        val encoded = Uri.encode(q)
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$encoded")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=$encoded&c=apps")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            launchCtx.startActivity(market)
            ActionResult.Success()
        } catch (_: ActivityNotFoundException) {
            try { launchCtx.startActivity(web); ActionResult.Success() }
            catch (e: ActivityNotFoundException) { ActionResult.Failure(FailureReason.NOT_ALLOWED, e.message) }
        }
    }

    // Opens Android's own uninstall dialog; the user still taps OK there.
    private fun uninstall(name: String): ActionResult {
        val a = findApp(name) ?: return ActionResult.Failure(FailureReason.APP_NOT_INSTALLED, name)
        launchCtx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult.Success()
    }
}
