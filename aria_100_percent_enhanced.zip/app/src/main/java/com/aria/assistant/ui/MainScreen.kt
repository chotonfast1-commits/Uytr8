package com.aria.assistant.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aria.assistant.*
import com.aria.assistant.service.ForegroundAssistantService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: AppViewModel, onSettings: () -> Unit, onMemory: () -> Unit, onHistory: () -> Unit, onPerf: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsStateWithLifecycle()
    val state by vm.ai.state.collectAsStateWithLifecycle()
    val msgs by vm.ai.messages.collectAsStateWithLifecycle()
    val pending by vm.ai.pendingConfirmation.collectAsStateWithLifecycle()
    val running by ForegroundAssistantService.running.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    var afterMic by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) afterMic?.invoke(); afterMic = null }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun withMic(block: () -> Unit) { if (AppContainer.permissions.status().microphone) block() else { afterMic = block; micLauncher.launch(Manifest.permission.RECORD_AUDIO) } }

    Scaffold(topBar = {
        TopAppBar(title = { Text(s.aiName) }, actions = {
            IconButton(onClick = onPerf) { Icon(Icons.Filled.Speed, stringResource(R.string.performance)) }
            IconButton(onClick = onMemory) { Icon(Icons.Filled.Memory, stringResource(R.string.memory)) }
            IconButton(onClick = onHistory) { Icon(Icons.Filled.History, stringResource(R.string.history)) }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, stringResource(R.string.settings)) }
        })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(state)
            Text(stringResource(when (state) {
                AssistantState.READY -> R.string.status_ready; AssistantState.LISTENING -> R.string.status_listening
                AssistantState.THINKING -> R.string.status_thinking; AssistantState.SPEAKING -> R.string.status_speaking
                AssistantState.EXECUTING -> R.string.status_executing }), style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(msgs) { m ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                        Surface(shape = RoundedCornerShape(14.dp), color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                            Text(m.text, Modifier.padding(10.dp), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            pending?.let {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                    Button(onClick = { vm.ai.submitText(ctx.getString(R.string.yes)) }) { Text(stringResource(R.string.yes)) }
                    OutlinedButton(onClick = { vm.ai.submitText(ctx.getString(R.string.no)) }) { Text(stringResource(R.string.no)) }
                }
            }
            LargeFloatingActionButton(onClick = {
                if (state == AssistantState.LISTENING) vm.ai.stopAll() else withMic { vm.ai.startTurn() }
            }, shape = CircleShape) { Icon(Icons.Filled.Mic, stringResource(R.string.mic_hint), Modifier.size(40.dp)) }
            Text(stringResource(R.string.mic_hint), style = MaterialTheme.typography.bodySmall)
            Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(enabled = !running, onClick = {
                    withMic {
                        if (Build.VERSION.SDK_INT >= 33 && !AppContainer.permissions.status().notifications) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        ForegroundAssistantService.start(ctx)
                    }
                }) { Text(stringResource(R.string.start_assistant)) }
                Button(enabled = running, onClick = { vm.ai.stopAll(); ForegroundAssistantService.stop(ctx) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text(stringResource(R.string.stop_assistant)) }
            }
        }
    }
}

@Composable
private fun Avatar(state: AssistantState) {
    val t = rememberInfiniteTransition(label = "pulse")
    val active = state != AssistantState.READY
    val scale by t.animateFloat(1f, if (active) 1.15f else 1.03f, infiniteRepeatable(tween(if (active) 600 else 2000), RepeatMode.Reverse), label = "s")
    val c = MaterialTheme.colorScheme
    Canvas(Modifier.size(120.dp).padding(8.dp)) {
        val r = size.minDimension / 2
        drawCircle(c.primary.copy(alpha = 0.25f), r * scale, Offset(center.x, center.y))
        drawCircle(c.primary, r * 0.7f, center)
        drawCircle(c.onPrimary, r * 0.18f, Offset(center.x - r * 0.25f, center.y - r * 0.1f))
        drawCircle(c.onPrimary, r * 0.18f, Offset(center.x + r * 0.25f, center.y - r * 0.1f))
    }
}
