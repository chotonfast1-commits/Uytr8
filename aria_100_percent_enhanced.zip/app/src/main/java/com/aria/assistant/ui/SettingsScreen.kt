package com.aria.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aria.assistant.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, onPerf: () -> Unit, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var name by remember(s.userName) { mutableStateOf(s.userName) }
    var ai by remember(s.aiName) { mutableStateOf(s.aiName) }
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.settings)) }, navigationIcon = {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.your_name)) }, singleLine = true)
            OutlinedTextField(ai, { ai = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.ai_name)) }, singleLine = true)
            Button(enabled = name.isNotBlank() && ai.isNotBlank(), onClick = { vm.saveSettings { it.copy(userName = name.trim(), aiName = ai.trim()) } }) { Text(stringResource(R.string.save)) }
            Text(stringResource(R.string.setup_lang_q), style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Language.entries.forEach { l -> FilterChip(s.language == l, { vm.saveSettings { it.copy(language = l) } }, { Text(l.label) }) } }
            Text(stringResource(R.string.setup_voice_q), style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.voice == VoiceGender.MALE, { vm.saveSettings { it.copy(voice = VoiceGender.MALE) } }, { Text(stringResource(R.string.male)) })
                FilterChip(s.voice == VoiceGender.FEMALE, { vm.saveSettings { it.copy(voice = VoiceGender.FEMALE) } }, { Text(stringResource(R.string.female)) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.continuous), Modifier.weight(1f))
                Switch(s.listeningMode == ListeningMode.CONTINUOUS, { on -> vm.saveSettings { it.copy(listeningMode = if (on) ListeningMode.CONTINUOUS else ListeningMode.PUSH_TO_TALK) } })
            }
            OutlinedButton(onClick = onPerf) { Text(stringResource(R.string.performance)) }
            Text(stringResource(R.string.setup_perm_title), style = MaterialTheme.typography.titleSmall)
            PermissionsPanel()
        }
    }
}
