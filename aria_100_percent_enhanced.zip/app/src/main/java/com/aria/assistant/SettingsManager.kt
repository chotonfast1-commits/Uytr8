package com.aria.assistant

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.SecureRandom

data class AuthToken(val token: String, val expiresAt: Long)

interface SettingsManager {
    val settings: StateFlow<UserSettings>
    fun update(transform: (UserSettings) -> UserSettings)
    /** Passphrase for the encrypted memory database; generated once and kept in Keystore-backed prefs. */
    fun databasePassphrase(): ByteArray
    /** Proxy session token (issued by /v1/register). Kept in encrypted prefs. */
    fun authToken(): AuthToken?
    fun saveAuthToken(t: AuthToken)
    fun clearAuthToken()
}

class EncryptedSettingsManager(context: Context) : SettingsManager {
    private val prefs = EncryptedSharedPreferences.create(
        context, "aria_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private val _settings = MutableStateFlow(load())
    override val settings: StateFlow<UserSettings> = _settings

    private fun load() = UserSettings(
        setupDone = prefs.getBoolean("setup_done", false),
        userName = prefs.getString("user_name", "") ?: "",
        aiName = prefs.getString("ai_name", "Aria") ?: "Aria",
        language = Language.from(prefs.getString("language", "en")),
        voice = runCatching { VoiceGender.valueOf(prefs.getString("voice", "FEMALE")!!) }.getOrDefault(VoiceGender.FEMALE),
        listeningMode = runCatching { ListeningMode.valueOf(prefs.getString("mode", "PUSH_TO_TALK")!!) }.getOrDefault(ListeningMode.PUSH_TO_TALK)
    )

    @Synchronized
    override fun update(transform: (UserSettings) -> UserSettings) {
        val s = transform(_settings.value)
        prefs.edit().putBoolean("setup_done", s.setupDone).putString("user_name", s.userName)
            .putString("ai_name", s.aiName).putString("language", s.language.tag)
            .putString("voice", s.voice.name).putString("mode", s.listeningMode.name).apply()
        _settings.value = s
    }

    override fun authToken(): AuthToken? {
        val t = prefs.getString("proxy_token", null) ?: return null
        return AuthToken(t, prefs.getLong("proxy_token_exp", 0L))
    }
    override fun saveAuthToken(t: AuthToken) { prefs.edit().putString("proxy_token", t.token).putLong("proxy_token_exp", t.expiresAt).apply() }
    override fun clearAuthToken() { prefs.edit().remove("proxy_token").remove("proxy_token_exp").apply() }

    @Synchronized
    override fun databasePassphrase(): ByteArray {
        val existing = prefs.getString("db_key", null)
        if (existing != null) return existing.toByteArray()
        val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val key = Base64.encodeToString(raw, Base64.NO_WRAP)
        prefs.edit().putString("db_key", key).apply()
        return key.toByteArray()
    }
}
