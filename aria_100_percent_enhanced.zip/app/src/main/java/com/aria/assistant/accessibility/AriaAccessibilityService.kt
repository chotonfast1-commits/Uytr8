package com.aria.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Acts only when AutomationManager asks. It never reads or stores screen content on its own. */
class AriaAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: AriaAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun root(): AccessibilityNodeInfo? = rootInActiveWindow

    fun clickByLabel(label: String): Boolean {
        val r = root() ?: return false
        val hits = r.findAccessibilityNodeInfosByText(label).filter { it.isVisibleToUser }
        for (n in hits) {
            var cur: AccessibilityNodeInfo? = n; var depth = 0
            while (cur != null && depth < 6) {
                if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur = cur.parent; depth++
            }
        }
        return false
    }

    fun scroll(forward: Boolean): Boolean {
        val node = findFirst(root()) { it.isScrollable } ?: return false
        return node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    /** Returns null if no field, false if refused (password field), true if set. */
    fun setFocusedText(text: String): Boolean? {
        val r = root() ?: return null
        val target = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findFirst(r) { it.isEditable } ?: return null
        if (target.isPassword) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun pressImeEnter(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        val f = root()?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    private fun findFirst(n: AccessibilityNodeInfo?, depth: Int = 0, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null || depth > 40) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) findFirst(n.getChild(i), depth + 1, pred)?.let { return it }
        return null
    }

    fun readVisible(max: Int = 4000): String? {
        val r = root() ?: return null
        if (r.packageName == packageName) return null
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 40 || sb.length >= max || !n.isVisibleToUser) return
            if (!n.isPassword) (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(r, 0)
        return sb.toString().trim()
    }

    fun clickableLabels(): List<String> {
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 40 || out.size >= 100) return
            if (n.isClickable && n.isVisibleToUser) (n.text ?: n.contentDescription)?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root(), 0)
        return out
    }
}
