package com.aria.assistant.ui

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aria.assistant.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {
    val settings = AppContainer.settings.settings
    val ai = AppContainer.ai
    val memories = AppContainer.memory.items.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveSettings(transform: (UserSettings) -> UserSettings) {
        val old = settings.value.language
        AppContainer.settings.update(transform)
        val new = settings.value.language
        if (new != old) AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(new.tag))
    }
    fun addMemory(t: String, onResult: (RememberResult) -> Unit) = viewModelScope.launch { onResult(AppContainer.memory.remember(t)) }
    fun editMemory(id: Long, t: String, onResult: (RememberResult) -> Unit) = viewModelScope.launch { onResult(AppContainer.memory.edit(id, t)) }
    fun deleteMemory(id: Long) = viewModelScope.launch { AppContainer.memory.delete(id) }
}
