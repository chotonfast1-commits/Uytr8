package com.aria.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

interface TextToSpeechManager {
    /** Suspends until finished. Returns false if TTS is unavailable (caller should rely on on-screen text). */
    suspend fun speak(text: String, language: Language, gender: VoiceGender): Boolean
    fun stop()
    fun shutdown()
}

class AndroidTtsManager(private val ctx: Context) : TextToSpeechManager {
    private var tts: TextToSpeech? = null
    private val ready = CompletableDeferred<Boolean>()
    private val waiting = ConcurrentHashMap<String, () -> Unit>()

    private fun ensure() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { status ->
            ready.complete(status == TextToSpeech.SUCCESS)
        }.also {
            it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = Unit
                override fun onDone(id: String?) { waiting.remove(id)?.invoke() }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { waiting.remove(id)?.invoke() }
                override fun onStop(id: String?, interrupted: Boolean) { waiting.remove(id)?.invoke() }
            })
        }
    }

    override suspend fun speak(text: String, language: Language, gender: VoiceGender): Boolean {
        ensure()
        if (!ready.await()) return false
        val t = tts ?: return false
        val locale = Locale.forLanguageTag(language.tag)
        if (t.setLanguage(locale) < TextToSpeech.LANG_AVAILABLE) return false
        pickVoice(t, language, gender)
        return suspendCancellableCoroutine { cont ->
            val id = UUID.randomUUID().toString()
            waiting[id] = { if (cont.isActive) cont.resume(true) }
            cont.invokeOnCancellation { waiting.remove(id); t.stop() }
            if (t.speak(text, TextToSpeech.QUEUE_ADD, null, id) == TextToSpeech.ERROR) { waiting.remove(id); if (cont.isActive) cont.resume(false) }
        }
    }

    // Android exposes no reliable gender field. Use a "male"/"female" hint in the voice name when present,
    // otherwise keep the best-quality voice and shift pitch.
    private fun pickVoice(t: TextToSpeech, language: Language, gender: VoiceGender) {
        val all = runCatching { t.voices }.getOrNull().orEmpty()
            .filter { it.locale.language == language.tag && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
        val hint = if (gender == VoiceGender.FEMALE) "female" else "male"
        fun byQuality(l: List<Voice>) = l.sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired }).firstOrNull()
        val named = all.filter { v -> v.name.lowercase().let { n -> n.contains(hint) && (hint == "female" || !n.contains("female")) } }
        val chosen = byQuality(named) ?: byQuality(all)
        if (chosen != null) t.voice = chosen
        t.setPitch(if (named.isNotEmpty()) 1.0f else if (gender == VoiceGender.FEMALE) 1.1f else 0.85f)
    }

    override fun stop() { tts?.stop(); waiting.values.toList().forEach { it() }; waiting.clear() }
    override fun shutdown() { tts?.shutdown(); tts = null }
}
