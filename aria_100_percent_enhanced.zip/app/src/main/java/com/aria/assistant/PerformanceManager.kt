package com.aria.assistant

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs

enum class TipKey { STORAGE, RAM, BATTERY_APPS, OK }
data class AppUsage(val label: String, val minutes: Long)
data class PerfSnapshot(
    val ramTotal: Long, val ramAvailable: Long, val lowMemory: Boolean,
    val storageTotal: Long, val storageFree: Long,
    val batteryPercent: Int, val charging: Boolean, val batteryTempC: Float?,
    val topApps: List<AppUsage>?, // null = usage access not granted
    val tips: List<TipKey>
)

interface PerformanceManager { fun snapshot(usageAccessGranted: Boolean): PerfSnapshot }

class AndroidPerformanceManager(private val ctx: Context) : PerformanceManager {
    override fun snapshot(usageAccessGranted: Boolean): PerfSnapshot {
        val mi = ActivityManager.MemoryInfo().also { (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it) }
        val st = StatFs(Environment.getDataDirectory().path)
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val temp = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.takeIf { it != Int.MIN_VALUE }?.div(10f)
        val apps = if (usageAccessGranted) topApps() else null
        val tips = buildList {
            if (st.availableBytes.toDouble() / st.totalBytes < 0.1) add(TipKey.STORAGE)
            if (mi.lowMemory || mi.availMem.toDouble() / mi.totalMem < 0.12) add(TipKey.RAM)
            if (!apps.isNullOrEmpty()) add(TipKey.BATTERY_APPS)
            if (isEmpty()) add(TipKey.OK)
        }
        return PerfSnapshot(mi.totalMem, mi.availMem, mi.lowMemory, st.totalBytes, st.availableBytes,
            if (lvl >= 0) lvl * 100 / scale else -1,
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL, temp, apps, tips)
    }

    private fun topApps(): List<AppUsage> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        return usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 24L * 3600_000, now)
            .filter { it.totalTimeInForeground > 60_000 && it.packageName != ctx.packageName }
            .groupBy { it.packageName }.mapValues { e -> e.value.sumOf { it.totalTimeInForeground } }
            .entries.sortedByDescending { it.value }.take(5).map { (pkg, ms) ->
                val label = runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
                AppUsage(label, ms / 60_000)
            }
    }
}
