package com.aria.assistant

import android.app.Application

/** Simple manual DI. Swap any implementation here; everything else depends on interfaces. */
object AppContainer {
    lateinit var settings: SettingsManager; private set
    lateinit var memory: MemoryManager; private set
    lateinit var permissions: PermissionManager; private set
    lateinit var performance: PerformanceManager; private set
    lateinit var ai: AIManager; private set

    fun init(app: Application) {
        settings = EncryptedSettingsManager(app)
        memory = EncryptedMemoryManager(app, settings)
        permissions = AndroidPermissionManager(app)
        performance = AndroidPerformanceManager(app)
        val reader: ScreenReader = AccessibilityScreenReader()
        ai = DefaultAIManager(app, settings, ProxyGeminiManager(settings), AndroidVoiceManager(app), AndroidTtsManager(app),
            memory, AndroidAutomationManager(app, reader), DefaultCommandParser(), DefaultConfirmationManager())
    }
}

class AriaApp : Application() {
    override fun onCreate() { super.onCreate(); AppContainer.init(this) }
}
