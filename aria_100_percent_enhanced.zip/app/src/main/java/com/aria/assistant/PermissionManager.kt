package com.aria.assistant

import android.Manifest
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.aria.assistant.accessibility.AriaAccessibilityService

data class PermissionStatus(val microphone: Boolean, val notifications: Boolean, val accessibility: Boolean, val batteryUnrestricted: Boolean, val usageAccess: Boolean)

interface PermissionManager {
    fun status(): PermissionStatus
    fun accessibilitySettingsIntent(): Intent
    fun batterySettingsIntent(): Intent
    fun usageAccessIntent(): Intent
    fun appDetailsIntent(): Intent
}

class AndroidPermissionManager(private val ctx: Context) : PermissionManager {
    override fun status() = PermissionStatus(
        microphone = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
        notifications = if (Build.VERSION.SDK_INT >= 33)
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else NotificationManagerCompat.from(ctx).areNotificationsEnabled(),
        accessibility = isAccessibilityEnabled(),
        batteryUnrestricted = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName),
        usageAccess = hasUsageAccess()
    )
    private fun isAccessibilityEnabled(): Boolean {
        val me = ComponentName(ctx, AriaAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
    private fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
        else @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
    private fun nt(i: Intent) = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    override fun accessibilitySettingsIntent() = nt(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    override fun batterySettingsIntent() = nt(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    override fun usageAccessIntent() = nt(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    override fun appDetailsIntent() = nt(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
}
