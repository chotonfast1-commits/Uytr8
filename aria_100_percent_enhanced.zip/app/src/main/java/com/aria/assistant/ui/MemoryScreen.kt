package com.aria.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aria.assistant.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(vm: AppViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by vm.memories.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MemoryItem?>(null) }
    var draft by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    fun handle(r: RememberResult) { error = if (r == RememberResult.RefusedSensitive) ctx.getString(R.string.mem_refused) else null; if (r == RememberResult.Saved) { editing = null; draft = "" } }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.memory)) }, navigationIcon = {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(stringResource(R.string.mem_note), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(draft, { draft = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(stringResource(R.string.mem_hint)) }, isError = error != null, supportingText = { error?.let { Text(it) } })
                Button(enabled = draft.isNotBlank(), onClick = {
                    val e = editing
                    if (e == null) vm.addMemory(draft, ::handle) else vm.editMemory(e.id, draft, ::handle)
                }) { Text(stringResource(if (editing == null) R.string.add else R.string.save)) }
            }
            if (items.isEmpty()) Text(stringResource(R.string.mem_empty))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { m ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(start = 12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(m.text, Modifier.weight(1f))
                            IconButton(onClick = { editing = m; draft = m.text }) { Icon(Icons.Filled.Edit, null) }
                            IconButton(onClick = { vm.deleteMemory(m.id); if (editing?.id == m.id) { editing = null; draft = "" } }) { Icon(Icons.Filled.Delete, stringResource(R.string.delete)) }
                        }
                    }
                }
            }
        }
    }
}
