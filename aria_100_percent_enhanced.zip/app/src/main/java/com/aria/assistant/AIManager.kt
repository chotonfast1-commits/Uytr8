package com.aria.assistant

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import com.aria.assistant.service.ForegroundAssistantService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale

interface AIManager {
    val state: StateFlow<AssistantState>
    val messages: StateFlow<List<ChatMessage>>
    val pendingConfirmation: StateFlow<PendingConfirmation?>
    val events: SharedFlow<UiEvent>
    /** Listens once, handles the utterance. Result: true = loop may continue, false = fatal (e.g. mic denied). */
    fun startTurn(): Deferred<Boolean>
    /** Typed text or confirmation-button answers go through the same pipeline as speech. */
    fun submitText(text: String)
    /** Cancels listening, speech, pending confirmation and any automation in progress. */
    fun stopAll()
}

class DefaultAIManager(
    private val ctx: Context,
    private val settings: SettingsManager,
    private val gemini: GeminiManager,
    private val voice: VoiceManager,
    private val tts: TextToSpeechManager,
    private val memory: MemoryManager,
    private val automation: AutomationManager,
    private val parser: CommandParser,
    private val confirmation: ConfirmationManager
) : AIManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    private val _state = MutableStateFlow(AssistantState.READY)
    override val state: StateFlow<AssistantState> = _state
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    override val messages: StateFlow<List<ChatMessage>> = _messages
    override val pendingConfirmation = confirmation.pending
    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 1)
    override val events: SharedFlow<UiEvent> = _events

    override fun startTurn(): Deferred<Boolean> {
        job?.cancel()
        val d = scope.async { guarded { turn() } }
        job = d
        return d
    }

    override fun submitText(text: String) {
        if (text.isBlank()) return
        job?.cancel()
        job = scope.launch { guarded { handle(text.trim()); true } }
    }

    override fun stopAll() {
        job?.cancel(); job = null
        tts.stop(); confirmation.clear()
        _state.value = AssistantState.READY
    }

    private suspend fun guarded(block: suspend () -> Boolean): Boolean = try { block() }
    catch (e: CancellationException) { _state.value = AssistantState.READY; throw e }
    catch (e: Exception) { // never crash the assistant on an unexpected error
        val s = settings.settings.value
        say(str(s, R.string.err_generic, s.address)); false
    }

    private suspend fun turn(): Boolean {
        val s = settings.settings.value
        _state.value = AssistantState.LISTENING
        return when (val r = voice.listen(s.language)) {
            is ListenResult.Text -> { handle(r.text); true }
            ListenResult.NoMatch -> {
                if (s.listeningMode == ListeningMode.PUSH_TO_TALK) say(str(s, R.string.err_nospeech)) else _state.value = AssistantState.READY
                true
            }
            is ListenResult.Error -> {
                val msg = when (r.kind) {
                    ListenError.PERMISSION_DENIED -> str(s, R.string.err_mic_denied)
                    ListenError.NETWORK -> str(s, R.string.err_network, s.address)
                    else -> str(s, R.string.err_generic, s.address)
                }
                say(msg); r.kind == ListenError.BUSY
            }
        }
    }

    private suspend fun handle(text: String) {
        val s = settings.settings.value
        val previousUser = _messages.value.lastOrNull { it.fromUser }?.text
        addMessage(true, text)

        confirmation.pending.value?.let { p ->
            when (confirmation.parseAnswer(text)) {
                Answer.YES -> { confirmation.clear(); execute(p.action, s) }
                Answer.NO -> { confirmation.clear(); say(str(s, R.string.cancelled)) }
                Answer.UNCLEAR -> say(str(s, R.string.confirm_reask))
            }
            return
        }

        when (val c = parser.parse(text)) {
            LocalCommand.Stop -> {
                tts.stop()
                if (ForegroundAssistantService.running.value) runCatching { ForegroundAssistantService.stop(ctx) }
                say(str(s, R.string.ack_stop))
            }
            LocalCommand.ShowMemory -> { _events.tryEmit(UiEvent.OpenMemory) }
            is LocalCommand.Remember -> {
                val what = c.payload.ifBlank { previousUser.orEmpty() }
                say(when (memory.remember(what)) {
                    RememberResult.Saved -> str(s, R.string.mem_saved)
                    RememberResult.RefusedSensitive -> str(s, R.string.mem_refused)
                    RememberResult.Empty -> str(s, R.string.err_nospeech)
                })
            }
            is LocalCommand.Forget -> {
                val ok = if (c.payload.isBlank()) memory.forgetLatest() else memory.forgetMatching(c.payload) > 0
                say(str(s, if (ok) R.string.mem_forgot else R.string.mem_none_match))
            }
            null -> converse(text, s)
        }
    }

    private suspend fun converse(text: String, s: UserSettings) {
        _state.value = AssistantState.THINKING
        val req = GeminiRequest(s.address, s.aiName, s.language, memory.snapshot(), _messages.value.dropLast(1), text)
        gemini.ask(req).fold(
            onSuccess = { respond(it, s) },
            onFailure = { e ->
                say(when (e) {
                    is GeminiError.Network -> str(s, R.string.err_network, s.address)
                    is GeminiError.Api -> when (e.errorCode) {
                        "rate_limited", "upstream_busy", "upstream_timeout" -> str(s, R.string.err_busy, s.address)
                        else -> str(s, R.string.err_generic, s.address)
                    }
                    else -> str(s, R.string.err_generic, s.address)
                })
            }
        )
    }

    private suspend fun respond(r: AiReply, s: UserSettings) {
        val action = r.action
        if (action == null) { say(r.reply); return }
        if (confirmation.requiresConfirmation(action, r.consequential)) {
            val prompt = r.confirmPrompt ?: when (action) {
                is AutomationAction.UninstallApp -> str(s, R.string.confirm_uninstall, s.address, action.name)
                else -> str(s, R.string.confirm_generic, s.address)
            }
            confirmation.request(PendingConfirmation(prompt, action))
            say(prompt); return
        }
        addMessage(false, r.reply)
        coroutineScope {
            val speech = launch { _state.value = AssistantState.SPEAKING; tts.speak(r.reply, s.language, s.voice) }
            execute(action, s, speak = false)
            speech.join()
        }
        _state.value = AssistantState.READY
    }

    private suspend fun execute(action: AutomationAction, s: UserSettings, speak: Boolean = true) {
        _state.value = AssistantState.EXECUTING
        when (val res = automation.execute(action)) {
            is ActionResult.Success -> {
                if (action is AutomationAction.ReadScreen && res.message != null) say(res.message.take(400))
                else if (action is AutomationAction.ReadScreen) say(str(s, R.string.err_not_found, s.address))
                else _state.value = AssistantState.READY
            }
            is ActionResult.Failure -> say(when (res.reason) {
                FailureReason.APP_NOT_INSTALLED -> str(s, R.string.err_app_missing, s.address, res.detail ?: "")
                FailureReason.ACCESSIBILITY_DISABLED -> str(s, R.string.err_acc_needed)
                FailureReason.ELEMENT_NOT_FOUND -> str(s, R.string.err_not_found, s.address)
                FailureReason.NOT_ALLOWED, FailureReason.INVALID_ARGUMENT -> str(s, R.string.err_not_allowed, s.address)
            })
        }
    }

    private suspend fun say(text: String) {
        val s = settings.settings.value
        addMessage(false, text)
        _state.value = AssistantState.SPEAKING
        try { tts.speak(text, s.language, s.voice) } finally { _state.value = AssistantState.READY }
    }

    private fun addMessage(fromUser: Boolean, text: String) { _messages.update { (it + ChatMessage(fromUser, text)).takeLast(60) } }

    private fun str(s: UserSettings, @StringRes id: Int, vararg a: Any): String {
        val cfg = Configuration(ctx.resources.configuration).apply { setLocale(Locale.forLanguageTag(s.language.tag)) }
        return ctx.createConfigurationContext(cfg).getString(id, *a)
    }
}
