package com.aria.assistant

enum class AssistantState { READY, LISTENING, THINKING, SPEAKING, EXECUTING }
enum class Language(val tag: String, val label: String) {
    EN("en", "English"), HI("hi", "हिन्दी"), BN("bn", "বাংলা");
    companion object { fun from(tag: String?) = entries.firstOrNull { it.tag == tag } ?: EN }
}
enum class VoiceGender { MALE, FEMALE }
enum class ListeningMode { PUSH_TO_TALK, CONTINUOUS }

data class UserSettings(
    val setupDone: Boolean = false,
    val userName: String = "",
    val aiName: String = "Aria",
    val language: Language = Language.EN,
    val voice: VoiceGender = VoiceGender.FEMALE,
    val listeningMode: ListeningMode = ListeningMode.PUSH_TO_TALK
) { val address: String get() = userName.ifBlank { "Sir" } }

data class ChatMessage(val fromUser: Boolean, val text: String, val time: Long = System.currentTimeMillis())
data class MemoryItem(val id: Long, val text: String, val createdAt: Long)

sealed interface AutomationAction {
    data class OpenApp(val name: String) : AutomationAction
    data class OpenUrl(val url: String) : AutomationAction
    data class InstallApp(val name: String) : AutomationAction
    data class Tap(val label: String) : AutomationAction
    data class Scroll(val forward: Boolean) : AutomationAction
    data class TypeText(val text: String) : AutomationAction
    data class SearchInApp(val query: String) : AutomationAction
    data class UninstallApp(val name: String) : AutomationAction
    data object Home : AutomationAction
    data object Back : AutomationAction
    data object Recents : AutomationAction
    data object ReadScreen : AutomationAction
}

enum class FailureReason { APP_NOT_INSTALLED, ACCESSIBILITY_DISABLED, ELEMENT_NOT_FOUND, NOT_ALLOWED, INVALID_ARGUMENT }
sealed interface ActionResult {
    data class Success(val message: String? = null) : ActionResult
    data class Failure(val reason: FailureReason, val detail: String? = null) : ActionResult
}

data class AiReply(val reply: String, val action: AutomationAction?, val consequential: Boolean, val confirmPrompt: String?)
data class PendingConfirmation(val prompt: String, val action: AutomationAction)
sealed interface UiEvent { data object OpenMemory : UiEvent; data object OpenHistory : UiEvent }

sealed class GeminiError(msg: String) : Exception(msg) {
    class NotConfigured : GeminiError("Proxy URL not configured")
    class Network(cause: Throwable) : GeminiError(cause.message ?: "network")
    class Api(val httpCode: Int, val errorCode: String?, val retryAfter: Int?) : GeminiError("HTTP $httpCode ${errorCode ?: ""}")
    class BadResponse : GeminiError("Unreadable response")
}
