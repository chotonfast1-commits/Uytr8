package com.aria.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

enum class ListenError { PERMISSION_DENIED, UNAVAILABLE, NETWORK, BUSY, OTHER }
sealed interface ListenResult {
    data class Text(val text: String) : ListenResult
    data object NoMatch : ListenResult
    data class Error(val kind: ListenError) : ListenResult
}

interface VoiceManager { suspend fun listen(language: Language): ListenResult }

class AndroidVoiceManager(private val ctx: Context) : VoiceManager {
    private val main = Handler(Looper.getMainLooper())

    override suspend fun listen(language: Language): ListenResult = withContext(Dispatchers.Main) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            return@withContext ListenResult.Error(ListenError.PERMISSION_DENIED)
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return@withContext ListenResult.Error(ListenError.UNAVAILABLE)
        suspendCancellableCoroutine { cont ->
            val rec = SpeechRecognizer.createSpeechRecognizer(ctx)
            fun finish(r: ListenResult) { if (cont.isActive) cont.resume(r); rec.destroy() }
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    finish(if (t.isNullOrBlank()) ListenResult.NoMatch else ListenResult.Text(t))
                }
                override fun onError(code: Int) = finish(when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ListenResult.NoMatch
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> ListenResult.Error(ListenError.PERMISSION_DENIED)
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> ListenResult.Error(ListenError.NETWORK)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> ListenResult.Error(ListenError.BUSY)
                    else -> ListenResult.Error(ListenError.OTHER)
                })
                override fun onReadyForSpeech(p: Bundle?) = Unit
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(v: Float) = Unit
                override fun onBufferReceived(b: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onPartialResults(b: Bundle?) = Unit
                override fun onEvent(t: Int, b: Bundle?) = Unit
            })
            val tag = when (language) { Language.EN -> "en-US"; Language.HI -> "hi-IN"; Language.BN -> "bn-IN" }
            rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
            cont.invokeOnCancellation { main.post { rec.cancel(); rec.destroy() } }
        }
    }
}
