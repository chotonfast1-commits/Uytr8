package com.aria.assistant

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class Answer { YES, NO, UNCLEAR }

interface ConfirmationManager {
    val pending: StateFlow<PendingConfirmation?>
    fun request(p: PendingConfirmation)
    fun clear()
    fun requiresConfirmation(action: AutomationAction, flaggedByAi: Boolean): Boolean
    fun parseAnswer(text: String): Answer
}

class DefaultConfirmationManager : ConfirmationManager {
    private val _pending = MutableStateFlow<PendingConfirmation?>(null)
    override val pending: StateFlow<PendingConfirmation?> = _pending
    override fun request(p: PendingConfirmation) { _pending.value = p }
    override fun clear() { _pending.value = null }

    // Consequential words: tapping/typing these must be confirmed even if the model did not flag them.
    private val risky = Regex("\\b(send|pay|buy|purchase|order|place order|checkout|delete|remove|uninstall|transfer|confirm|submit|reset|erase|bhejo|भेजें|भेजो|পাঠাও)\\b", RegexOption.IGNORE_CASE)

    override fun requiresConfirmation(action: AutomationAction, flaggedByAi: Boolean) = flaggedByAi || when (action) {
        is AutomationAction.UninstallApp -> true
        is AutomationAction.Tap -> risky.containsMatchIn(action.label)
        else -> false
    }

    private val yes = setOf("yes", "yeah", "yep", "ok", "okay", "sure", "continue", "confirm", "haan", "han", "haa", "ha", "theek", "kar", "karo", "हाँ", "हां", "जी", "ठीक", "करो", "হ্যাঁ", "হ্যা", "ঠিক", "করো")
    private val no = setOf("no", "nope", "cancel", "stop", "dont", "don't", "nahi", "nahin", "mat", "na", "नहीं", "नही", "मत", "না", "নাহ", "থাক", "বাতিল")
    override fun parseAnswer(text: String): Answer {
        val tokens = text.lowercase().split(Regex("[\\s,.!?]+")).filter { it.isNotBlank() }
        return when {
            tokens.any { it in no } -> Answer.NO   // check NO first: "nahi, mat karo"
            tokens.any { it in yes } -> Answer.YES
            else -> Answer.UNCLEAR
        }
    }
}
