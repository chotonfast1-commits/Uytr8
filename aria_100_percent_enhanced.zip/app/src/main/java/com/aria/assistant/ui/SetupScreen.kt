package com.aria.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aria.assistant.*

@Composable
fun SetupScreen(vm: AppViewModel, onDone: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var aiName by remember { mutableStateOf("Aria") }
    var lang by remember { mutableStateOf(Language.EN) }
    var voice by remember { mutableStateOf(VoiceGender.FEMALE) }
    val last = 4

    Scaffold { pad ->
        Column(Modifier.padding(pad).padding(24.dp).fillMaxSize()) {
            LinearProgressIndicator(progress = { (step + 1f) / (last + 1) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(24.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                when (step) {
                    0 -> { Text(stringResource(R.string.setup_name_q), style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(stringResource(R.string.setup_name_hint)) }) }
                    1 -> { Text(stringResource(R.string.setup_ai_q), style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(aiName, { aiName = it }, Modifier.fillMaxWidth(), singleLine = true) }
                    2 -> { Text(stringResource(R.string.setup_lang_q), style = MaterialTheme.typography.headlineSmall)
                        Language.entries.forEach { l -> FilterChip(lang == l, { lang = l }, { Text(l.label) }) } }
                    3 -> { Text(stringResource(R.string.setup_voice_q), style = MaterialTheme.typography.headlineSmall)
                        FilterChip(voice == VoiceGender.MALE, { voice = VoiceGender.MALE }, { Text(stringResource(R.string.male)) })
                        FilterChip(voice == VoiceGender.FEMALE, { voice = VoiceGender.FEMALE }, { Text(stringResource(R.string.female)) }) }
                    else -> { Text(stringResource(R.string.setup_perm_title), style = MaterialTheme.typography.headlineSmall); PermissionsPanel() }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { if (step > 0) step-- }, enabled = step > 0) { Text(stringResource(R.string.back)) }
                Button(
                    enabled = when (step) { 0 -> name.isNotBlank(); 1 -> aiName.isNotBlank(); else -> true },
                    onClick = {
                        if (step < last) step++ else {
                            vm.saveSettings { it.copy(setupDone = true, userName = name.trim(), aiName = aiName.trim(), language = lang, voice = voice) }
                            onDone()
                        }
                    }
                ) { Text(stringResource(if (step < last) R.string.next else R.string.finish)) }
            }
        }
    }
}
