package com.aria.assistant

sealed interface LocalCommand {
    data class Remember(val payload: String) : LocalCommand
    data class Forget(val payload: String) : LocalCommand
    data object ShowMemory : LocalCommand
    data object Stop : LocalCommand
}

interface CommandParser { fun parse(text: String): LocalCommand? }

/** Handles only memory/stop commands locally (EN/Hinglish/HI/BN); everything else goes to Gemini. */
class DefaultCommandParser : CommandParser {
    private val stop = setOf("stop", "ruko", "ruk jao", "ruk ja", "बंद करो", "रुको", "রুকো", "থামো")
    private val show = listOf("meri memory dikhao", "memory dikhao", "show my memory", "show memory", "मेरी मेमोरी दिखाओ", "मेमोरी दिखाओ", "আমার মেমরি দেখাও", "মেমরি দেখাও")
    private val remember = listOf("yaad rakho", "yaad rakhna", "yad rakho", "remember this", "remember that", "remember", "याद रखो", "याद रखना", "মনে রাখো")
    private val forget = listOf("bhool jao", "bhul jao", "forget this", "forget that", "forget", "भूल जाओ", "ভুলে যাও")
    private val fillers = Regex("\\b(isko|ise|ye baat|yeh baat|ye|yeh|this|that|please|plz|ko)\\b|इसको|इसे|यह बात|ये बात", RegexOption.IGNORE_CASE)

    override fun parse(text: String): LocalCommand? {
        val t = text.trim().lowercase().trimEnd('.', '!', '?')
        if (t in stop) return LocalCommand.Stop
        if (show.any { t.contains(it) }) return LocalCommand.ShowMemory
        extract(t, remember)?.let { return LocalCommand.Remember(it) }
        extract(t, forget)?.let { return LocalCommand.Forget(it) }
        return null
    }
    private fun extract(t: String, triggers: List<String>): String? {
        val trig = triggers.firstOrNull { t.contains(it) } ?: return null
        return t.replace(trig, " ").replace(fillers, " ").replace(Regex("\\s+"), " ").trim(' ', ',', ':')
    }
}
