package com.aria.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class GeminiRequest(
    val userName: String, val aiName: String, val language: Language,
    val memories: List<String>, val history: List<ChatMessage>, val message: String
)

interface GeminiManager { suspend fun ask(request: GeminiRequest): Result<AiReply> }

/**
 * Talks to the Aria proxy (see /proxy). The Gemini key exists only on the server.
 *  1. POST /v1/register  (header X-Aria-Registration) -> short-lived signed session token, stored encrypted.
 *  2. POST /v1/assistant (Bearer token) -> { reply, action?, consequential, confirm_prompt? }
 * Errors arrive as { "error": { "code", "message", "retry_after_seconds"? } } and become GeminiError.Api.
 * Only text, approved memories and the last few chat turns are sent. No audio, no screen content.
 */
class ProxyGeminiManager(
    private val settings: SettingsManager,
    baseUrl: String = BuildConfig.PROXY_BASE_URL,
    private val registrationKey: String = BuildConfig.REGISTRATION_KEY
) : GeminiManager {
    private val base = baseUrl.trimEnd('/')
    private val tokenLock = Mutex()
    private val configured get() = base.startsWith("https://") && !base.contains("your-proxy") && registrationKey.isNotBlank()

    private class Http(val code: Int, val text: String, val retryAfter: Int?)

    override suspend fun ask(request: GeminiRequest): Result<AiReply> = withContext(Dispatchers.IO) {
        if (!configured) return@withContext Result.failure(GeminiError.NotConfigured())
        try {
            val body = JSONObject().apply {
                put("user_name", request.userName); put("ai_name", request.aiName); put("language", request.language.tag)
                put("memories", JSONArray(request.memories)); put("message", request.message)
                put("history", JSONArray().also { a -> request.history.takeLast(6).forEach {
                    a.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("text", it.text)) } })
            }.toString()
            var r = post("/v1/assistant", "Authorization", "Bearer ${ensureToken(false)}", body)
            if (r.code == 401 && errorCode(r.text) == "invalid_token") { // expired/rotated: register once more
                settings.clearAuthToken()
                r = post("/v1/assistant", "Authorization", "Bearer ${ensureToken(true)}", body)
            }
            if (r.code !in 200..299) return@withContext Result.failure(apiError(r))
            Result.success(parse(r.text))
        } catch (e: IOException) { Result.failure(GeminiError.Network(e))
        } catch (e: org.json.JSONException) { Result.failure(GeminiError.BadResponse())
        } catch (e: GeminiError) { Result.failure(e) }
    }

    private suspend fun ensureToken(force: Boolean): String = tokenLock.withLock {
        val cur = settings.authToken()
        if (!force && cur != null && cur.expiresAt - System.currentTimeMillis() > 86_400_000L) return cur.token
        val r = post("/v1/register", "X-Aria-Registration", registrationKey, "{}")
        if (r.code != 200) throw apiError(r)
        val j = JSONObject(r.text)
        val t = AuthToken(j.getString("token"), j.getLong("expires_at"))
        settings.saveAuthToken(t); t.token
    }

    private fun post(path: String, headerName: String, headerValue: String, body: String): Http {
        val c = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 30_000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty(headerName, headerValue)
        }
        try {
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            return Http(code, text, c.getHeaderField("Retry-After")?.toIntOrNull())
        } finally { c.disconnect() }
    }

    private fun errorCode(text: String): String? =
        runCatching { JSONObject(text).optJSONObject("error")?.optString("code")?.ifBlank { null } }.getOrNull()

    private fun apiError(r: Http) = GeminiError.Api(r.code, errorCode(r.text), r.retryAfter)

    private fun parse(raw: String): AiReply {
        val j = JSONObject(raw)
        val reply = j.optString("reply").ifBlank { throw GeminiError.BadResponse() }
        val a = j.optJSONObject("action")
        val t = a?.optString("target").orEmpty()
        val action: AutomationAction? = when (a?.optString("type")) {
            "open_app" -> AutomationAction.OpenApp(t)
            "open_url" -> AutomationAction.OpenUrl(t)
            "home" -> AutomationAction.Home; "back" -> AutomationAction.Back; "recents" -> AutomationAction.Recents
            "tap" -> AutomationAction.Tap(t)
            "scroll_down" -> AutomationAction.Scroll(true); "scroll_up" -> AutomationAction.Scroll(false)
            "type_text" -> AutomationAction.TypeText(t)
            "search_in_app" -> AutomationAction.SearchInApp(t)
            "read_screen" -> AutomationAction.ReadScreen
            "install_app" -> AutomationAction.InstallApp(t)
            "uninstall_app" -> AutomationAction.UninstallApp(t)
            else -> null
        }
        val confirm = if (j.isNull("confirm_prompt")) null else j.optString("confirm_prompt").ifBlank { null }
        return AiReply(reply, action, j.optBoolean("consequential", false), confirm)
    }
}
