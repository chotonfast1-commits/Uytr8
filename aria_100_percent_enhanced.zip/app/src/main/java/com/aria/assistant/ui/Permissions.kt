package com.aria.assistant.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.aria.assistant.AppContainer
import com.aria.assistant.R

/** Explains each permission before offering the button that requests it. Refreshes after returning from Settings. */
@Composable
fun PermissionsPanel() {
    val ctx = LocalContext.current
    val pm = AppContainer.permissions
    var st by remember { mutableStateOf(pm.status()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { st = pm.status() }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { st = pm.status() }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { st = pm.status() }
    fun open(i: Intent) = runCatching { ctx.startActivity(i) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PermRow(R.string.perm_mic_why, st.microphone) { mic.launch(Manifest.permission.RECORD_AUDIO) }
        PermRow(R.string.perm_acc_why, st.accessibility, R.string.open_settings) { open(pm.accessibilitySettingsIntent()) }
        PermRow(R.string.perm_notif_why, st.notifications) {
            if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else open(pm.appDetailsIntent())
        }
        PermRow(R.string.perm_batt_why, st.batteryUnrestricted, R.string.open_settings) { open(pm.batterySettingsIntent()) }
        Text(stringResource(R.string.perm_overlay_note), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun PermRow(why: Int, granted: Boolean, action: Int = R.string.grant, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(why), style = MaterialTheme.typography.bodyMedium)
            if (granted) Text(stringResource(R.string.granted), color = MaterialTheme.colorScheme.primary)
            else OutlinedButton(onClick = onClick) { Text(stringResource(action)) }
        }
    }
}
