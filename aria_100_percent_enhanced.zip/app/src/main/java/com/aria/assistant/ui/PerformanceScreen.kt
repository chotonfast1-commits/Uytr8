package com.aria.assistant.ui

import android.text.format.Formatter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aria.assistant.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var snap by remember { mutableStateOf<PerfSnapshot?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        snap = withContext(Dispatchers.Default) { AppContainer.performance.snapshot(AppContainer.permissions.status().usageAccess) }
    }
    fun sz(b: Long) = Formatter.formatFileSize(ctx, b)
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.performance)) },
        navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
        actions = { TextButton(onClick = { tick++ }) { Text(stringResource(R.string.refresh)) } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val p = snap
            if (p == null) CircularProgressIndicator() else {
                Meter(stringResource(R.string.ram), "${sz(p.ramTotal - p.ramAvailable)} / ${sz(p.ramTotal)}", 1f - p.ramAvailable.toFloat() / p.ramTotal)
                Meter(stringResource(R.string.storage), "${sz(p.storageTotal - p.storageFree)} / ${sz(p.storageTotal)}", 1f - p.storageFree.toFloat() / p.storageTotal)
                Meter(stringResource(R.string.battery), buildString {
                    append(if (p.batteryPercent >= 0) "${p.batteryPercent}%" else "—"); if (p.charging) append(" ⚡"); p.batteryTempC?.let { append("  ${"%.1f".format(it)}°C") } },
                    if (p.batteryPercent >= 0) p.batteryPercent / 100f else 0f)
                p.topApps?.let { apps -> apps.forEach { Text("${it.label} — ${it.minutes} min", style = MaterialTheme.typography.bodyMedium) } }
                if (p.topApps == null) {
                    Text(stringResource(R.string.usage_access_why), style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = { runCatching { ctx.startActivity(AppContainer.permissions.usageAccessIntent()) } }) { Text(stringResource(R.string.open_settings)) }
                }
                Text(stringResource(R.string.tips), style = MaterialTheme.typography.titleSmall)
                p.tips.forEach { Text(stringResource(when (it) { TipKey.STORAGE -> R.string.tip_storage; TipKey.RAM -> R.string.tip_ram; TipKey.BATTERY_APPS -> R.string.tip_battery; TipKey.OK -> R.string.tip_ok })) }
                Text(stringResource(R.string.bg_note), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Meter(title: String, value: String, fraction: Float) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("$title: $value")
            LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
    }
}
