package com.aria.assistant

import com.aria.assistant.accessibility.AriaAccessibilityService

interface ScreenReader {
    fun isAvailable(): Boolean
    fun visibleText(): String?
    fun clickableLabels(): List<String>
}

class AccessibilityScreenReader : ScreenReader {
    private val svc get() = AriaAccessibilityService.instance
    override fun isAvailable() = svc != null
    override fun visibleText() = svc?.readVisible()
    override fun clickableLabels() = svc?.clickableLabels().orEmpty()
}
