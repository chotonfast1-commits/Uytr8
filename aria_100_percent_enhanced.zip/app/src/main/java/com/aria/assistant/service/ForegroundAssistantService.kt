package com.aria.assistant.service

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.aria.assistant.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/** Started only by an explicit user tap. Persistent notification with a Stop action; Stop cancels all automation. */
class ForegroundAssistantService : Service() {
    companion object {
        const val ACTION_START = "com.aria.assistant.START"
        const val ACTION_STOP = "com.aria.assistant.STOP"
        private const val CHANNEL = "aria_running"
        private const val NOTIF_ID = 1
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running

        fun start(ctx: Context): Boolean {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            ContextCompat.startForegroundService(ctx, Intent(ctx, ForegroundAssistantService::class.java).setAction(ACTION_START))
            return true
        }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, ForegroundAssistantService::class.java).setAction(ACTION_STOP)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        try {
            startAsForeground()
        } catch (e: Exception) { // e.g. mic permission revoked
            _running.value = false; stopSelf(); return START_NOT_STICKY
        }
        _running.value = true
        if (loop?.isActive != true) loop = scope.launch { supervise() }
        return START_NOT_STICKY // never silently restart: the user must start the assistant
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, ForegroundAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val name = AppContainer.settings.settings.value.aiName
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle(name)
            .setContentText(getString(R.string.status_ready)).setOngoing(true).setContentIntent(open)
            .addAction(0, getString(R.string.stop_assistant), stop).build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    /** In CONTINUOUS mode keep taking turns; in push-to-talk mode only hold state and the notification. */
    private suspend fun supervise() {
        var failures = 0
        AppContainer.settings.settings.map { it.listeningMode }.distinctUntilChanged().collectLatest { mode ->
            if (mode != ListeningMode.CONTINUOUS) return@collectLatest
            while (currentCoroutineContext().isActive) {
                val ok = try { AppContainer.ai.startTurn().await() }
                catch (e: CancellationException) { currentCoroutineContext().ensureActive(); false }
                catch (e: Exception) { false }
                if (ok) failures = 0 else if (++failures >= 3) { shutdown(); return@collectLatest }
                delay(400)
            }
        }
    }

    private fun shutdown() {
        AppContainer.ai.stopAll()
        loop?.cancel(); _running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() { scope.cancel(); AppContainer.ai.stopAll(); _running.value = false; super.onDestroy() }
}
