package com.aria.assistant

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Entity(tableName = "memories")
data class MemoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val text: String, val createdAt: Long)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC") fun observe(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memories ORDER BY createdAt DESC") suspend fun all(): List<MemoryEntity>
    @Insert suspend fun insert(e: MemoryEntity): Long
    @Query("UPDATE memories SET text = :text WHERE id = :id") suspend fun update(id: Long, text: String)
    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM memories WHERE text LIKE '%' || :q || '%'") suspend fun deleteMatching(q: String): Int
}

@Database(entities = [MemoryEntity::class], version = 1, exportSchema = false)
abstract class AriaDatabase : RoomDatabase() { abstract fun memoryDao(): MemoryDao }

sealed interface RememberResult { data object Saved : RememberResult; data object RefusedSensitive : RememberResult; data object Empty : RememberResult }

interface MemoryManager {
    val items: Flow<List<MemoryItem>>
    suspend fun remember(text: String): RememberResult
    suspend fun edit(id: Long, text: String): RememberResult
    suspend fun delete(id: Long)
    suspend fun forgetMatching(query: String): Int
    suspend fun forgetLatest(): Boolean
    suspend fun snapshot(): List<String>
}

class EncryptedMemoryManager(context: Context, settings: SettingsManager) : MemoryManager {
    private val dao: MemoryDao = run {
        System.loadLibrary("sqlcipher")
        Room.databaseBuilder(context, AriaDatabase::class.java, "aria_memory.db")
            .openHelperFactory(SupportOpenHelperFactory(settings.databasePassphrase()))
            .build().memoryDao()
    }
    override val items = dao.observe().map { l -> l.map { MemoryItem(it.id, it.text, it.createdAt) } }

    // Memory is only ever written on explicit user request; obvious secrets are refused.
    private val sensitive = Regex("(password|passcode|\\bpin\\b|\\botp\\b|\\bcvv\\b|card number|aadhaar|aadhar|\\bssn\\b|पासवर्ड|পাসওয়ার্ড|\\b\\d{9,19}\\b)", RegexOption.IGNORE_CASE)

    private fun check(t: String): RememberResult? = when {
        t.isBlank() -> RememberResult.Empty
        sensitive.containsMatchIn(t) -> RememberResult.RefusedSensitive
        else -> null
    }
    override suspend fun remember(text: String): RememberResult {
        val t = text.trim(); check(t)?.let { return it }
        dao.insert(MemoryEntity(text = t, createdAt = System.currentTimeMillis())); return RememberResult.Saved
    }
    override suspend fun edit(id: Long, text: String): RememberResult {
        val t = text.trim(); check(t)?.let { return it }
        dao.update(id, t); return RememberResult.Saved
    }
    override suspend fun delete(id: Long) = dao.delete(id)
    override suspend fun forgetMatching(query: String) = if (query.isBlank()) 0 else dao.deleteMatching(query.trim())
    override suspend fun forgetLatest(): Boolean { val l = dao.all().firstOrNull() ?: return false; dao.delete(l.id); return true }
    override suspend fun snapshot() = dao.all().map { it.text }
}
