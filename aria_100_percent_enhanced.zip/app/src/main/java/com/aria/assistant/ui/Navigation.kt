package com.aria.assistant.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aria.assistant.UiEvent

@Composable
fun AriaNav(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val s by vm.settings.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { vm.ai.events.collect { when (it) { UiEvent.OpenMemory -> nav.navigate("memory"); UiEvent.OpenHistory -> nav.navigate("history") } } }
    NavHost(nav, startDestination = if (s.setupDone) "main" else "setup") {
        composable("setup") { SetupScreen(vm) { nav.navigate("main") { popUpTo("setup") { inclusive = true } } } }
        composable("main") { MainScreen(vm, onSettings = { nav.navigate("settings") }, onMemory = { nav.navigate("memory") }, onHistory = { nav.navigate("history") }, onPerf = { nav.navigate("performance") }) }
        composable("memory") { MemoryScreen(vm) { nav.popBackStack() } }
        composable("history") { HistoryScreen(vm.ai.messages.collectAsStateWithLifecycle().value) { nav.popBackStack() } }
        composable("settings") { SettingsScreen(vm, onPerf = { nav.navigate("performance") }) { nav.popBackStack() } }
        composable("performance") { PerformanceScreen { nav.popBackStack() } }
    }
}
